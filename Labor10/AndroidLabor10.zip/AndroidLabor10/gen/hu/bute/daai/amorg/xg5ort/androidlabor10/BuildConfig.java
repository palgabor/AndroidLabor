/** Automatically generated file. DO NOT MODIFY */
package hu.bute.daai.amorg.xg5ort.androidlabor10;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}